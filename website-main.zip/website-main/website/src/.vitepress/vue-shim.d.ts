declare module '*.vue' {
  import type { Component } from 'vue'

  const _default: Component
  export default _default
}
