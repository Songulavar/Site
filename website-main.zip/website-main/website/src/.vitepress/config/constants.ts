export const GITHUB_EXTENSION_JSON = 'https://raw.githubusercontent.com/tachiyomiorg/extensions/repo/index.json'
