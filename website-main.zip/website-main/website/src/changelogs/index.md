---
title: Changelogs
description: Changelogs of all Tachiyomi stable releases.
lastUpdated: false
editLink: false
prev: false
next: false
---

<script setup>
import ChangelogsList from "@theme/components/ChangelogsList.vue";
</script>

# Changelogs

Changelogs of all Tachiyomi stable releases, which are also available [on GitHub](https://github.com/tachiyomiorg/tachiyomi/releases). Preview releases can be seen [on GitHub](https://github.com/tachiyomiorg/tachiyomi-preview/releases).

<ChangelogsList />
