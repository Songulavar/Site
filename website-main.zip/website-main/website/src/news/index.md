---
title: News
description: Collection of news and announcements about Tachiyomi.
lastUpdated: false
editLink: false
prev: false
next: false
---

<script setup>
import News from "@theme/components/News.vue";
import RssLink from "@theme/components/RssLink.vue";
</script>

# News

Collection of news and announcements about Tachiyomi.

Also available as <RssLink />.

<News />
