---
title: Browse
titleTemplate: Frequently Asked Questions
description: Frequently Asked Questions about Browse.
---

# Browse
Frequently Asked Questions about Browse.

## Why can't I see installed sources?

### If the extension language differs from your device's primary language
Enable the source's language at <nav to="sources">, tap on **Filter**, then turn on the language of the desired source.

### If it's an NSFW extension
Navigate to <nav to="browse"> and check the **Show in sources and extensions list** option.
